# Shinobi Front

Ein Naruto-inspirierter RoWorld-Fork. Originalprojekt: https://github.com/lukechatton/roworld
Der RoWorld-Simulationskern, die Steuerung, das Lobby-System und das Freischaltsystem sind die Basis. Die spielbare Standardkarte heißt Shinobi World. Ihre Geografie ist für das Spiel gezeichnet und enthält 14 Naruto-Dörfer als Startpunkte. Die Jutsu-Symbole werden direkt in der Oberfläche gezeichnet. Die Lizenz und die ursprünglichen Credits liegen im Projekt.

## In Roblox Studio spielen

1. Die mitgelieferte Datei Shinobi-Front.rbxlx in Roblox Studio öffnen.
2. Im Studio mit F5 testen und im Spielmenü Solo auswählen.
3. Einen Chakra Shrine bauen. In lokalen Solo-Testpartien in Roblox Studio füllt der HUD-Button „Testgold auf 250M“ das Gold auf und schaltet die Jutsus für diese Partie frei. Nach Nutzung des Testgold-Buttons vergibt diese Partie keine Sterne. Rasengan und Planetary Devastation sind von Anfang an verfügbar. Bijūdama und Tengai Shinsei lassen sich im Arsenal mit Sternen freischalten. Jede Anwendung kostet zusätzlich Gold im Match.

| Rang | Jutsu | Äußerer Radius auf der Weltkarte | Gold pro Einsatz |
| --- | --- | ---: | ---: |
| 1 | Tengai Shinsei | 140 Felder plus Fragmente | 12.000.000 |
| 2 | Planetary Devastation | 100 Felder | 5.000.000 |
| 3 | Bijūdama | 60 Felder | 2.500.000 |
| 4 | Rasengan | 30 Felder | 750.000 |

Robux-Produkte und das Abo der Original-Experience sind deaktiviert. Einige Kartenbilder, Strukturgrafiken und Vorschaueffekte stammen weiterhin aus RoWorld.

## Aus dem Quellcode bauen

Mit Rojo 7.7.1 im Projektordner:

    rojo build release.project.json -o Shinobi-Front.rbxlx

Die Karte lässt sich mit Lune und `lune run tools/maps/make_shinobi.luau` aus dem Quellcode neu generieren.

Die internen Airfront-Pfade bleiben für die RoWorld-Module erhalten.
